package com.example.tradehybrid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
