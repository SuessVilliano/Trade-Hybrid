import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated({'auto-width': 406, 'auto-height': 865})
class BasicCards2 extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const BasicCards2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: 16,
        ),
        child: NFlex(
          direction: Axis.vertical,
          spacing: 20,
          children: [
            FlexSizedBox(
              width: double.infinity,
              child: NFlex(
                direction: Axis.horizontal,
                spacing: 164,
                children: [
                  FlexSizedBox(
                    width: null,
                    child: Text(
                      'Welcome Back!',
                      style: TextStyle(
                        shadows: [],
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  FlexSizedBox(
                    width: 40,
                    height: 40,
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(4291085508),
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [],
                      ),
                    ),
                  )
                ],
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
              ),
            ),
            FlexSizedBox(
              width: 358,
              height: 752,
              child: NFlex(
                direction: Axis.vertical,
                spacing: 20,
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  FlexSizedBox(
                    width: double.infinity,
                    child: NFlex(
                      direction: Axis.horizontal,
                      spacing: 18,
                      children: [
                        FlexSizedBox(
                          height: double.infinity,
                          child: NFlex(
                            direction: Axis.vertical,
                            spacing: 6,
                            children: [
                              FlexSizedBox(
                                width: double.infinity,
                                child: GestureDetector(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: const Color(4291085508),
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: [],
                                    ),
                                  ),
                                ),
                                flex: 1,
                              ),
                              FlexSizedBox(
                                width: null,
                                height: null,
                                child: Text(
                                  'Category',
                                  style: TextStyle(shadows: [], fontSize: 16),
                                ),
                              )
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          flex: 1,
                        ),
                        FlexSizedBox(
                          height: double.infinity,
                          child: NFlex(
                            direction: Axis.vertical,
                            spacing: 6,
                            children: [
                              FlexSizedBox(
                                width: double.infinity,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(4291085508),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [],
                                  ),
                                ),
                                flex: 1,
                              ),
                              FlexSizedBox(
                                width: null,
                                height: null,
                                child: Text(
                                  'Category',
                                  style: TextStyle(shadows: [], fontSize: 16),
                                ),
                              )
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          flex: 1,
                        )
                      ],
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                    ),
                    flex: 1,
                  ),
                  FlexSizedBox(
                    width: double.infinity,
                    child: NFlex(
                      direction: Axis.horizontal,
                      spacing: 18,
                      children: [
                        FlexSizedBox(
                          height: double.infinity,
                          child: NFlex(
                            direction: Axis.vertical,
                            spacing: 6,
                            children: [
                              FlexSizedBox(
                                width: double.infinity,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(4291085508),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [],
                                  ),
                                ),
                                flex: 1,
                              ),
                              FlexSizedBox(
                                width: null,
                                height: null,
                                child: Text(
                                  'Category',
                                  style: TextStyle(shadows: [], fontSize: 16),
                                ),
                              )
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          flex: 1,
                        ),
                        FlexSizedBox(
                          height: double.infinity,
                          child: NFlex(
                            direction: Axis.vertical,
                            spacing: 6,
                            children: [
                              FlexSizedBox(
                                width: double.infinity,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(4291085508),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [],
                                  ),
                                ),
                                flex: 1,
                              ),
                              FlexSizedBox(
                                width: null,
                                height: null,
                                child: Text(
                                  'Category',
                                  style: TextStyle(shadows: [], fontSize: 16),
                                ),
                              )
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          flex: 1,
                        )
                      ],
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                    ),
                    flex: 1,
                  ),
                  FlexSizedBox(
                    width: double.infinity,
                    child: NFlex(
                      direction: Axis.horizontal,
                      spacing: 18,
                      children: [
                        FlexSizedBox(
                          height: double.infinity,
                          child: NFlex(
                            direction: Axis.vertical,
                            spacing: 6,
                            children: [
                              FlexSizedBox(
                                width: double.infinity,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(4291085508),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [],
                                  ),
                                ),
                                flex: 1,
                              ),
                              FlexSizedBox(
                                width: null,
                                height: null,
                                child: Text(
                                  'Category',
                                  style: TextStyle(shadows: [], fontSize: 16),
                                ),
                              )
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          flex: 1,
                        ),
                        FlexSizedBox(
                          height: double.infinity,
                          child: NFlex(
                            direction: Axis.vertical,
                            spacing: 6,
                            children: [
                              FlexSizedBox(
                                width: double.infinity,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(4291085508),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [],
                                  ),
                                ),
                                flex: 1,
                              ),
                              FlexSizedBox(
                                width: null,
                                height: null,
                                child: Text(
                                  'Category',
                                  style: TextStyle(shadows: [], fontSize: 16),
                                ),
                              )
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          flex: 1,
                        )
                      ],
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                    ),
                    flex: 1,
                  ),
                  FlexSizedBox(
                    width: double.infinity,
                    child: NFlex(
                      direction: Axis.horizontal,
                      spacing: 18,
                      children: [
                        FlexSizedBox(
                          height: double.infinity,
                          child: NFlex(
                            direction: Axis.vertical,
                            spacing: 6,
                            children: [
                              FlexSizedBox(
                                width: double.infinity,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(4291085508),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [],
                                  ),
                                ),
                                flex: 1,
                              ),
                              FlexSizedBox(
                                width: null,
                                height: null,
                                child: Text(
                                  'Category',
                                  style: TextStyle(shadows: [], fontSize: 16),
                                ),
                              )
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          flex: 1,
                        ),
                        FlexSizedBox(
                          height: double.infinity,
                          child: NFlex(
                            direction: Axis.vertical,
                            spacing: 6,
                            children: [
                              FlexSizedBox(
                                width: double.infinity,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(4291085508),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [],
                                  ),
                                ),
                                flex: 1,
                              ),
                              FlexSizedBox(
                                width: null,
                                height: null,
                                child: Text(
                                  'Category',
                                  style: TextStyle(shadows: [], fontSize: 16),
                                ),
                              )
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          flex: 1,
                        )
                      ],
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                    ),
                    flex: 1,
                  ),
                  FlexSizedBox(
                    width: double.infinity,
                    child: NFlex(
                      direction: Axis.horizontal,
                      spacing: 18,
                      children: [
                        FlexSizedBox(
                          height: double.infinity,
                          child: NFlex(
                            direction: Axis.vertical,
                            spacing: 6,
                            children: [
                              FlexSizedBox(
                                width: double.infinity,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(4291085508),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [],
                                  ),
                                ),
                                flex: 1,
                              ),
                              FlexSizedBox(
                                width: null,
                                height: null,
                                child: Text(
                                  'Category',
                                  style: TextStyle(shadows: [], fontSize: 16),
                                ),
                              )
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          flex: 1,
                        ),
                        FlexSizedBox(
                          height: double.infinity,
                          child: NFlex(
                            direction: Axis.vertical,
                            spacing: 6,
                            children: [
                              FlexSizedBox(
                                width: double.infinity,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(4291085508),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [],
                                  ),
                                ),
                                flex: 1,
                              ),
                              FlexSizedBox(
                                width: null,
                                height: null,
                                child: Text(
                                  'Category',
                                  style: TextStyle(shadows: [], fontSize: 16),
                                ),
                              )
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          flex: 1,
                        )
                      ],
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                    ),
                    flex: 1,
                  )
                ],
              ),
            )
          ],
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
        ),
      ),
    );
  }
}
