import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated({'fbCollectionType': 'fbMainCollection'})
class products {
  @NowaGenerated({'loader': 'auto-from-json'})
  factory products.fromJson({required Map<String, dynamic> json}) {
    return products(param: json['param'] ?? '', images: json['images'] ?? '');
  }

  @NowaGenerated({'loader': 'auto-constructor'})
  const products({this.param = '', this.images = ''});

  final String? images;

  final String? param;

  @NowaGenerated({'loader': 'auto-to-json'})
  Map<String, dynamic> toJson() {
    return {'param': param, 'images': images};
  }

  @NowaGenerated({'loader': 'auto-copy-with'})
  products copyWith({String? param, String? images}) {
    return products(param: param ?? this.param, images: images ?? this.images);
  }
}
