import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:tradehybrid/integrations/firestore_collections.dart';
import 'package:tradehybrid/integrations/firebase.dart';

@NowaGenerated()
class FirestoreService {
  FirestoreService._();

  factory FirestoreService() {
    return _instance;
  }

  static final FirestoreService _instance = FirestoreService._();

  static Future<DocumentReference<products>> addProduct(
      {products? addedParam =
          products(param: addedParam, images: addProduct())}) {
    return FirebaseService.firestore
        .collection('products')
        .withConverter<products>(
            fromFirestore: (snapshot, _) =>
                products.fromJson(json: snapshot.data()!),
            toFirestore: (objProducts, _) => objProducts.toJson())
        .add(addedParam!);
  }

  static Future<QuerySnapshot<products>> getProduct() {
    return FirebaseService.firestore
        .collection('products')
        .withConverter<products>(
            fromFirestore: (snapshot, _) =>
                products.fromJson(json: snapshot.data()!),
            toFirestore: (objProducts, _) => objProducts.toJson())
        .get();
  }
}
