import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
class SupabaseService {
  static final supabase = Supabase.instance.client;

  static Future setup() {
    return Supabase.initialize(
        url: 'https://flhnakrhzznqefnkqgbn.supabase.co',
        anonKey:
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZsaG5ha3JoenpucWVmbmtxZ2JuIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTcyMTQyODUxNSwiZXhwIjoyMDM3MDA0NTE1fQ.kaXXi-vraTK2QhVIMNVBADSa1uQ1hzW-MTPrRs_C-eE');
  }

  static SupabaseQueryBuilder querymembers = supabase.from('members');

  static Future insertmembers(members record) async {
    await supabase
        .from('members')
        .insert(record.toJson()..removeWhere((key, value) => value == null));
  }
}

@NowaGenerated()
class members {
  @NowaGenerated({'loader': 'auto-from-json'})
  factory members.fromJson({required Map<String, dynamic> json}) {
    return members(
      id: json['id'],
      created_at: json['created_at'],
      first_name: json['first_name'],
      last_name: json['last_name'],
      email: json['email'],
      phone: json['phone'],
      password: json['password'],
    );
  }

  @NowaGenerated({'loader': 'auto-constructor'})
  const members(
      {this.id,
      this.created_at,
      this.first_name,
      this.last_name,
      this.email,
      this.phone,
      this.password});

  final String? password;

  final String? phone;

  final String? email;

  final String? last_name;

  final String? first_name;

  final String? created_at;

  final int? id;

  @NowaGenerated({'loader': 'auto-to-json'})
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'created_at': created_at,
      'first_name': first_name,
      'last_name': last_name,
      'email': email,
      'phone': phone,
      'password': password,
    };
  }

  @NowaGenerated({'loader': 'auto-copy-with'})
  members copyWith(
      {int? id,
      String? created_at,
      String? first_name,
      String? last_name,
      String? email,
      String? phone,
      String? password}) {
    return members(
      id: id ?? this.id,
      created_at: created_at ?? this.created_at,
      first_name: first_name ?? this.first_name,
      last_name: last_name ?? this.last_name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      password: password ?? this.password,
    );
  }
}
