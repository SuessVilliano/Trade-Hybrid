import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated({'auto-width': 400, 'auto-height': 870})
class News extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const News({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: 16,
        ),
        child: NFlex(
          direction: Axis.vertical,
          spacing: 20,
          children: [
            FlexSizedBox(
              width: double.infinity,
              child: NFlex(
                direction: Axis.horizontal,
                spacing: 164,
                children: [
                  FlexSizedBox(
                    width: null,
                    child: Text(
                      'Welcome Back!',
                      style: TextStyle(
                        shadows: [],
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  FlexSizedBox(
                    width: 40,
                    height: 40,
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(4291085508),
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [],
                      ),
                    ),
                  )
                ],
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
              ),
            ),
            FlexSizedBox(
              width: 358,
              height: 767,
              child: SingleChildScrollView(
                child: NFlex(
                  direction: Axis.vertical,
                  spacing: 20,
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    ),
                    FlexSizedBox(
                      width: double.infinity,
                      height: 80,
                      child: NFlex(
                        direction: Axis.horizontal,
                        spacing: 14,
                        children: [
                          FlexSizedBox(
                            width: 80,
                            height: 80,
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(4291085508),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [],
                              ),
                            ),
                          ),
                          FlexSizedBox(
                            child: NFlex(
                              direction: Axis.vertical,
                              spacing: 4,
                              children: [
                                FlexSizedBox(
                                  width: null,
                                  height: null,
                                  child: Text(
                                    'Sit ex consequat qui laborum.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w900),
                                  ),
                                ),
                                FlexSizedBox(
                                  child: Text(
                                    'Duis proident fugiat cillum culpa mollit labore fugiat et minim.',
                                    style: TextStyle(
                                        shadows: [],
                                        fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            flex: 1,
                          )
                        ],
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
        ),
      ),
    );
  }
}
