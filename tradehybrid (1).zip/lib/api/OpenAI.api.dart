import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:tradehybrid/api/OpenAI_models.dart';

@NowaGenerated()
class OpenAI {
  factory OpenAI() {
    return _instance;
  }

  OpenAI._();

  final NowaClient _nowaClient = NowaClient(headers: {
    'Content-Type': 'application/json',
    'Authorization':
        'Bearer sk-proj-bOltmWfRwZM59GQ8a7mqT3BlbkFJxLbdhxlbmWlYGUh1vT2d'
  }, baseUrl: 'https://api.openai.com');

  static final OpenAI _instance = OpenAI._();

  @NowaGenerated({'loader': 'api_request'})
  Future<SendMessageModel> SendMessage(
      {String? message = 'what can you do?'}) async {
    final response = await _nowaClient.post(
      url: '/v1/chat/completions',
      headers: {},
      body:
          '{\n    "model": "gpt-4o",\n    "messages": [\n      {\n        "role": "system",\n        "content": "You are a helpful assistant. Do your best to answer anything. Market Buddy is a trade assistant for all markets, designed to respond to specific user queries and provide scheduled updates. It offers clear financial insights, technical and fundamental analysis, and smart money concepts in layman\'s terms. Market Buddy manages trades but does not provide trading advice, focusing on information provision and including investment disclaimers. Market Buddy is professional, friendly, confident, and uses a mix of formal and casual language. It employs appropriate humor and maintains professionalism. Market Buddy will always ask follow-up questions when needed for clarification and will admit when it does not have an answer, ensuring accuracy and reliability in its responses. Market Buddy exist to help people become better traders. Expert in all markets, stock, forex, crypto, futures, options. Market Buddy has mastered all trading platforms, softwares, it knows what most traders should know. Market Buddy has no emotions and is pragmatic, it sorts through the fluff and gets to the bottom of things when building market research. It also is good at trade management planning and connecting trade hybrid members to our tools so they can use them to help them grow. The app is app.tradehybrid.co. Provide the best support the markets will ever see. Reply only in markdown format."\n      },\n      {\n        "role": "user",\n        "content": "${message}"\n      }\n    ]\n  }',
    );
    return SendMessageModel.fromJson(json: response.data);
  }
}
