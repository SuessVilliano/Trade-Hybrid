import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
class SendMessageModelmessage {
  @NowaGenerated({'loader': 'auto-from-json'})
  factory SendMessageModelmessage.fromJson(
      {required Map<String, dynamic> json}) {
    return SendMessageModelmessage(
        role: json['role'], content: json['content']);
  }

  @NowaGenerated({'loader': 'auto-constructor'})
  const SendMessageModelmessage({this.role, this.content});

  final String? content;

  final String? role;

  @NowaGenerated({'loader': 'auto-to-json'})
  Map<String, dynamic> toJson() {
    return {'role': role, 'content': content};
  }

  @NowaGenerated({'loader': 'auto-copy-with'})
  SendMessageModelmessage copyWith({String? role, String? content}) {
    return SendMessageModelmessage(
        role: role ?? this.role, content: content ?? this.content);
  }
}

@NowaGenerated()
class SendMessageModelchoices {
  @NowaGenerated({'loader': 'auto-from-json'})
  factory SendMessageModelchoices.fromJson(
      {required Map<String, dynamic> json}) {
    return SendMessageModelchoices(
      index: json['index'],
      message: SendMessageModelmessage.fromJson(json: json['message'] ?? {}),
      logprobs: json['logprobs']!,
      finish_reason: json['finish_reason'],
    );
  }

  @NowaGenerated({'loader': 'auto-constructor'})
  const SendMessageModelchoices(
      {this.index, this.message, required this.logprobs, this.finish_reason});

  final String? finish_reason;

  final dynamic logprobs;

  final SendMessageModelmessage? message;

  final double? index;

  @NowaGenerated({'loader': 'auto-to-json'})
  Map<String, dynamic> toJson() {
    return {
      'index': index,
      'message': message?.toJson(),
      'logprobs': logprobs,
      'finish_reason': finish_reason,
    };
  }

  @NowaGenerated({'loader': 'auto-copy-with'})
  SendMessageModelchoices copyWith(
      {double? index,
      SendMessageModelmessage? message,
      required dynamic logprobs,
      String? finish_reason}) {
    return SendMessageModelchoices(
      index: index ?? this.index,
      message: message ?? this.message,
      logprobs: logprobs ?? this.logprobs,
      finish_reason: finish_reason ?? this.finish_reason,
    );
  }
}

@NowaGenerated()
class SendMessageModelusage {
  @NowaGenerated({'loader': 'auto-from-json'})
  factory SendMessageModelusage.fromJson({required Map<String, dynamic> json}) {
    return SendMessageModelusage(
      prompt_tokens: json['prompt_tokens'],
      completion_tokens: json['completion_tokens'],
      total_tokens: json['total_tokens'],
    );
  }

  @NowaGenerated({'loader': 'auto-constructor'})
  const SendMessageModelusage(
      {this.prompt_tokens, this.completion_tokens, this.total_tokens});

  final double? total_tokens;

  final double? completion_tokens;

  final double? prompt_tokens;

  @NowaGenerated({'loader': 'auto-to-json'})
  Map<String, dynamic> toJson() {
    return {
      'prompt_tokens': prompt_tokens,
      'completion_tokens': completion_tokens,
      'total_tokens': total_tokens,
    };
  }

  @NowaGenerated({'loader': 'auto-copy-with'})
  SendMessageModelusage copyWith(
      {double? prompt_tokens,
      double? completion_tokens,
      double? total_tokens}) {
    return SendMessageModelusage(
      prompt_tokens: prompt_tokens ?? this.prompt_tokens,
      completion_tokens: completion_tokens ?? this.completion_tokens,
      total_tokens: total_tokens ?? this.total_tokens,
    );
  }
}

@NowaGenerated()
class SendMessageModel {
  @NowaGenerated({'loader': 'auto-from-json'})
  factory SendMessageModel.fromJson({required Map<String, dynamic> json}) {
    return SendMessageModel(
      id: json['id'],
      object: json['object'],
      created: json['created'],
      model: json['model'],
      choices: json['choices']
          ?.map<SendMessageModelchoices?>(
              (element) => SendMessageModelchoices.fromJson(json: element))
          ?.toList(),
      usage: SendMessageModelusage.fromJson(json: json['usage'] ?? {}),
      system_fingerprint: json['system_fingerprint'],
    );
  }

  @NowaGenerated({'loader': 'auto-constructor'})
  const SendMessageModel(
      {this.id,
      this.object,
      this.created,
      this.model,
      this.choices,
      this.usage,
      this.system_fingerprint});

  final String? system_fingerprint;

  final SendMessageModelusage? usage;

  final List<SendMessageModelchoices?>? choices;

  final String? model;

  final double? created;

  final String? object;

  final String? id;

  @NowaGenerated({'loader': 'auto-to-json'})
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'object': object,
      'created': created,
      'model': model,
      'choices': choices?.map((element) => element!.toJson()).toList(),
      'usage': usage?.toJson(),
      'system_fingerprint': system_fingerprint,
    };
  }

  @NowaGenerated({'loader': 'auto-copy-with'})
  SendMessageModel copyWith(
      {String? id,
      String? object,
      double? created,
      String? model,
      List<SendMessageModelchoices?>? choices,
      SendMessageModelusage? usage,
      String? system_fingerprint}) {
    return SendMessageModel(
      id: id ?? this.id,
      object: object ?? this.object,
      created: created ?? this.created,
      model: model ?? this.model,
      choices: choices ?? this.choices,
      usage: usage ?? this.usage,
      system_fingerprint: system_fingerprint ?? this.system_fingerprint,
    );
  }
}
