import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:flutter_svg/svg.dart';

@NowaGenerated({'auto-width': 389, 'auto-height': 870})
class Login extends StatefulWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const Login({super.key});

  @override
  State<Login> createState() {
    return _LoginState();
  }
}

@NowaGenerated()
class _LoginState extends State<Login> {
  TextEditingController text = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          alignment: const Alignment(0, 0),
          children: [
            const Positioned(
              top: 46,
              left: 68,
              width: 253,
              height: 233,
              child: SvgPicture(
                SvgAssetLoader('assets/liv8-logo.svg'),
              ),
            ),
            Positioned(
              top: 279,
              left: 68,
              width: 253,
              height: 94,
              child: TextFormField(
                controller: text,
              ),
            )
          ],
        ),
      ),
    );
  }
}
