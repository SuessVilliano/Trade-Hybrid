import 'package:shared_preferences/shared_preferences.dart';
import 'package:tradehybrid/integrations/supabase.i.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:tradehybrid/firebase_options.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tradehybrid/memberinfo.dart';
import 'package:tradehybrid/BasicCards2.dart';
import 'package:tradehybrid/chat.dart';
import 'package:tradehybrid/list1.dart';
import 'package:tradehybrid/Login.dart';
import 'package:tradehybrid/LoginScreen.dart';
import 'package:tradehybrid/News.dart';
import 'package:tradehybrid/ProductView.dart';
import 'package:tradehybrid/Signals.dart';
import 'package:tradehybrid/signup.dart';
import 'package:tradehybrid/Tools.dart';
import 'package:tradehybrid/trade.dart';
import 'package:tradehybrid/Welcome.dart';

@NowaGenerated()
late final SharedPreferences sharedPrefs;

@NowaGenerated()
main() async {
  WidgetsFlutterBinding.ensureInitialized();
  sharedPrefs = await SharedPreferences.getInstance();
  await SupabaseService.setup();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

@NowaGenerated()
class MyApp extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<memberinfo>(
      create: (context) => memberinfo(),
      child: MaterialApp(
        initialRoute: 'chat',
        routes: {
          'BasicCards2': (context) => const BasicCards2(),
          'chat': (context) => const chat(),
          'list1': (context) => const list1(),
          'Login': (context) => const Login(),
          'LoginScreen': (context) => const LoginScreen(),
          'News': (context) => const News(),
          'ProductView': (context) => const ProductView(),
          'Signals': (context) => const Signals(),
          'signup': (context) => const signup(),
          'Tools': (context) => const Tools(),
          'trade': (context) => const trade(),
          'Welcome': (context) => const Welcome(),
        },
      ),
    );
  }
}
