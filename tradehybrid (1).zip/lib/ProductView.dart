import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:tradehybrid/integrations/firestore_service.dart';
import 'package:tradehybrid/integrations/firestore_collections.dart';

@NowaGenerated({'auto-width': 345, 'auto-height': 145})
class ProductView extends StatefulWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const ProductView(
      {this.product = const products(param: 'Default Name'), super.key});

  final products? product;

  @override
  State<ProductView> createState() {
    return _ProductViewState();
  }
}

@NowaGenerated()
class _ProductViewState extends State<ProductView> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: const Alignment(0, 0),
      children: [
        Positioned(
          top: 14,
          left: 123,
          width: 222,
          height: 62,
          child: Text(
            widget.product!.param!,
            style: const TextStyle(),
          ),
        ),
        Positioned(
          top: 94,
          left: 172,
          height: 34,
          child: CustomButton(
            onPressed: () {
              FirestoreService.addProduct(
                  addedParam: const products(
                      param: 'Test Name',
                      images:
                          'https://s3.tradingview.com/snapshots/s/SFQweWk3.png'));
            },
            child: const Text(
              'Button',
              style: TextStyle(),
            ),
          ),
        ),
        Positioned(
          top: 0,
          left: 0,
          width: 114,
          height: 137,
          child: Container(
            decoration: BoxDecoration(
              color: Color(0xffc4c4c4),
              borderRadius: BorderRadius.circular(0),
              image: DecorationImage(
                  fit: BoxFit.cover,
                  image: NetworkImage(widget.product!.images!)),
            ),
          ),
        )
      ],
    );
  }
}
