import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

@NowaGenerated()
class memberinfo extends ChangeNotifier {
  factory memberinfo.of(BuildContext context, {bool listen = true}) {
    return Provider.of<memberinfo>(context, listen: listen);
  }

  memberinfo();

  TextEditingController? password = TextEditingController();

  TextEditingController? phone = TextEditingController();

  TextEditingController? email = TextEditingController();

  TextEditingController? last_name = TextEditingController();

  TextEditingController? first_name = TextEditingController();
}
