import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:tradehybrid/ChatMessageObject.dart';

@NowaGenerated({'auto-width': 248, 'auto-height': 88})
class MessageBubble extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const MessageBubble(
      {this.chatMessageParam =
          const ChatMessageObject(isUserSender: true, message: ''),
      super.key});

  final ChatMessageObject? chatMessageParam;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 0,
        right: 0,
        top: 1,
        bottom: 10,
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(createBL()),
            bottomRight: Radius.circular(createBR()),
          ),
          border: Border.all(color: const Color(16777215), width: 1),
          color: createColor1(),
        ),
        child: Padding(
          padding: const EdgeInsets.only(
            left: 10,
            right: 10,
            top: 10,
            bottom: 10,
          ),
          child: NFlex(
            direction: Axis.vertical,
            spacing: 2,
            children: [
              Text(
                createText(),
                style: TextStyle(
                  fontFamily: 'Figtree',
                  fontWeight: FontWeight.w700,
                  color: const Color(4278190080),
                  backgroundColor: const Color(15724527),
                ),
                textAlign: TextAlign.start,
              ),
              SizedBox(
                child: Markdown(
                  chatMessageParam!.message!,
                ),
              )
            ],
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
          ),
        ),
      ),
    );
  }

  String createText() {
    if (chatMessageParam!.isUserSender!) {
      return '🤖 You';
    } else {
      return '🐮 Assistant';
    }
  }

  double createBL() {
    if (chatMessageParam!.isUserSender!) {
      return 0;
    } else {
      return 20;
    }
  }

  double createBR() {
    if (chatMessageParam!.isUserSender!) {
      return 20;
    } else {
      return 0;
    }
  }

  Color? createColor() {
    return const Color(4294967295);
  }

  Color? createColor1() {
    if (chatMessageParam!.isUserSender!) {
      return const Color(4290032306);
    } else {
      return const Color(4278236415);
    }
  }
}
