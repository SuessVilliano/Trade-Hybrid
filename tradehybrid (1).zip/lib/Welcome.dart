import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated({'auto-width': 385, 'auto-height': 870})
class Welcome extends StatefulWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const Welcome({super.key});

  @override
  State<Welcome> createState() {
    return _WelcomeState();
  }
}

@NowaGenerated()
class _WelcomeState extends State<Welcome> {
  String var1 = 'Hi \$';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          alignment: const Alignment(0, 0),
          children: [
            Positioned(
              top: 70,
              left: 23,
              width: 257,
              height: 53,
              child: Text(
                createText2(),
                style: const TextStyle(),
              ),
            )
          ],
        ),
      ),
    );
  }

  String createText() {
    return 'Hi';
  }

  String createText1() {
    return 'Hi \$';
  }

  String createText2() {
    return 'Hi \$';
  }
}
