import 'package:firebase_core/firebase_core.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
class DefaultFirebaseOptions {
  static FirebaseOptions? get currentPlatform {
    if (NPlatform.isWeb) {
      return web;
    }
    else if(NPlatform.isAndroid){
      return android;
    }
    if(NPlatform.isIOS || NPlatform.isMacOs){
      return ios;
    }
    return null;
  }
  
  static const FirebaseOptions web = FirebaseOptions(
  apiKey: 'AIzaSyBcuw8CEtLhUOWRu3vVAjXPaxA8bPSz0Vg',
  appId: '1:439853528752:web:ac5255a57c8b1f0605ed75',
  messagingSenderId: '439853528752',
  projectId: 'trade-hybrid-66c8f',
  authDomain: 'trade-hybrid-66c8f.firebaseapp.com',
  databaseId: 'null',
  storageBucket: 'trade-hybrid-66c8f.appspot.com',
  measurementId: 'G-LZG1W7YFR0'
);

  static const FirebaseOptions ios = FirebaseOptions(
  apiKey: 'AIzaSyAq179mQfh5gkghtDPmZ-uwUvb68oebWvA',
  appId: '1:439853528752:ios:5e43a89dde8212e905ed75',
  messagingSenderId: '439853528752',
  projectId: 'trade-hybrid-66c8f',
  databaseId: '',
  storageBucket: 'trade-hybrid-66c8f.appspot.com',
  androidClientId: '',
  iosBundleId: 'com.example.tradehybrid',
);

      static const FirebaseOptions android = FirebaseOptions(
      apiKey: 'AIzaSyCbcLxJhYAVpBQxvmL71sooqP4soZUAX8E',
      appId: '1:439853528752:android:d6c27c651d671d1f05ed75',
      messagingSenderId: '439853528752',
      projectId: 'trade-hybrid-66c8f',
      databaseId: '',
      storageBucket: 'trade-hybrid-66c8f.appspot.com',
    );
    
}
