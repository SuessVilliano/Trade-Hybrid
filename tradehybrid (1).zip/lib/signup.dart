import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:tradehybrid/integrations/firebase.dart';
import 'package:tradehybrid/Welcome.dart';
import 'package:tradehybrid/Login.dart';

@NowaGenerated({'auto-width': 393, 'auto-height': 808})
class signup extends StatefulWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const signup({super.key});

  @override
  State<signup> createState() {
    return _signupState();
  }
}

@NowaGenerated()
class _signupState extends State<signup> {
  TextEditingController text5 = TextEditingController();

  TextEditingController text4 = TextEditingController();

  TextEditingController text3 = TextEditingController();

  TextEditingController text2 = TextEditingController();

  TextEditingController text1 = TextEditingController();

  TextEditingController text = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          alignment: const Alignment(0, 0),
          children: [
            const Positioned(
              top: 72,
              left: 113.5,
              child: Text(
                'Sign Up',
                style: TextStyle(fontFamily: 'Alfa Slab One', fontSize: 44),
                textAlign: TextAlign.center,
              ),
            ),
            Positioned(
              top: 155,
              left: 29,
              width: 337,
              child: NFlex(
                direction: Axis.vertical,
                spacing: 11,
                children: [
                  FlexSizedBox(
                    width: 247,
                    height: 52,
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: 'first name...',
                        filled: true,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4)),
                        prefixIcon: const Icon(
                          IconData(61433, fontFamily: 'MaterialIcons'),
                          color: Color(4278190080),
                        ),
                      ),
                      controller: text,
                    ),
                  ),
                  FlexSizedBox(
                    width: 247,
                    height: 52,
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: 'last name...',
                        filled: true,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4)),
                        prefixIcon: const Icon(
                          IconData(61433, fontFamily: 'MaterialIcons'),
                          color: Color(4278190080),
                        ),
                      ),
                      controller: text1,
                    ),
                  ),
                  FlexSizedBox(
                    width: 247,
                    height: 52,
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: 'email...',
                        filled: true,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4)),
                        prefixIcon: const Icon(
                          IconData(57473, fontFamily: 'MaterialIcons'),
                          color: Color(4278190080),
                        ),
                      ),
                      controller: text2,
                    ),
                  ),
                  FlexSizedBox(
                    width: 247,
                    height: 52,
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: 'phone...',
                        filled: true,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4)),
                        prefixIcon: const Icon(
                          IconData(58822, fontFamily: 'MaterialIcons'),
                          color: Color(4278190080),
                        ),
                      ),
                      controller: text3,
                    ),
                  ),
                  FlexSizedBox(
                    width: 247,
                    height: 52,
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: 'password...',
                        filled: true,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4)),
                        prefixIcon: const Icon(
                          IconData(58490, fontFamily: 'MaterialIcons'),
                          color: Color(4278190080),
                        ),
                      ),
                      controller: text4,
                    ),
                  ),
                  FlexSizedBox(
                    width: 247,
                    height: 52,
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: 'password again...',
                        filled: true,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4)),
                        prefixIcon: const Icon(
                          IconData(58490, fontFamily: 'MaterialIcons'),
                          color: Color(4278190080),
                        ),
                      ),
                      controller: text5,
                    ),
                  ),
                  FlexSizedBox(
                    width: null,
                    height: 40,
                    child: CustomButton(
                      onPressed: () {},
                      child: const Text(
                        'Sign Up',
                        style: TextStyle(color: Color(4294967295)),
                      ),
                      color: const Color(4278190080),
                    ),
                  )
                ],
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
              ),
            ),
            Positioned(
              top: 676,
              left: 113.5,
              width: 170,
              height: 45,
              child: CustomButton(
                onPressed: () {
                  FirebaseService().signInWithGoogle().then((value) {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => const Welcome()));
                  }, onError: (error) {
                    print('error: ${error}');
                  });
                },
                child: const Text(
                  'Login With Google',
                  style: TextStyle(color: Color(4278190080)),
                ),
                color: const Color(4291282887),
              ),
            ),
            Positioned(
              top: 605,
              left: 113.5,
              width: 173.5,
              height: 42,
              child: GestureDetector(
                child: Text(
                  'Already have an account?\nSign in here',
                  style: TextStyle(decoration: TextDecoration.underline),
                  textAlign: TextAlign.center,
                ),
                onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => const Login()));
                },
                trackpadScrollToScaleFactor: const Offset(0, 0),
              ),
            )
          ],
        ),
      ),
    );
  }
}
