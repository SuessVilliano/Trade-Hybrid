import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
class ChatMessageObject {
  @NowaGenerated({'loader': 'auto-constructor'})
  const ChatMessageObject(
      {this.message = 'default message', this.isUserSender = true});

  @NowaGenerated({'loader': 'auto-from-json'})
  factory ChatMessageObject.fromJson({required Map<String, dynamic> json}) {
    return ChatMessageObject(
        message: json['message'] ?? 'default message',
        isUserSender: json['isUserSender'] ?? false);
  }

  final String? message;

  final bool? isUserSender;

  @NowaGenerated({'loader': 'auto-to-json'})
  Map<String, dynamic> toJson() {
    return {'message': message, 'isUserSender': isUserSender};
  }

  @NowaGenerated({'loader': 'auto-copy-with'})
  ChatMessageObject copyWith({String? message, bool? isUserSender}) {
    return ChatMessageObject(
        message: message ?? this.message,
        isUserSender: isUserSender ?? this.isUserSender);
  }
}
