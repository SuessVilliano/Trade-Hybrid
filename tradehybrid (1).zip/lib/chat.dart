import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:tradehybrid/ChatMessageObject.dart';
import 'package:tradehybrid/MessageBubble.dart';
import 'package:tradehybrid/api/OpenAI.api.dart';

@NowaGenerated({'auto-width': 401, 'auto-height': 737})
class chat extends StatefulWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const chat({super.key});

  @override
  State<chat> createState() {
    return _chatState();
  }
}

@NowaGenerated()
class _chatState extends State<chat> {
  List<ChatMessageObject?>? messageList = [];

  TextEditingController textcontroller = TextEditingController();

  bool? isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: const Color(4291085508),
          borderRadius: BorderRadius.circular(0),
          image: DecorationImage(
              fit: BoxFit.cover,
              image: const AssetImage(
                  'assets/DALL·E 2024-06-27 15.00.23 - A headshot of an AI bot_human with a white background, highly detailed and realistic, no errors or extra parts. The AI has a sleek, professional look,.webp')),
        ),
        child: Padding(
          padding: const EdgeInsets.only(
            left: 10,
            right: 10,
            top: 10,
            bottom: 10,
          ),
          child: SafeArea(
            child: NFlex(
              direction: Axis.vertical,
              spacing: 0,
              children: [
                FlexSizedBox(
                  width: double.infinity,
                  child: ListView.builder(
                    reverse: true,
                    padding: const EdgeInsets.only(
                      left: 10,
                      right: 10,
                      top: 10,
                      bottom: 10,
                    ),
                    shrinkWrap: false,
                    separatorBuilder: (context, index) => const Divider(
                      color: Color(4291085508),
                      thickness: 1,
                    ),
                    itemCount: messageList?.length,
                    itemBuilder: (context, index) {
                      final ChatMessageObject? element = messageList![index];
                      return SizedBox(
                        width: null,
                        height: null,
                        child: MessageBubble(
                          chatMessageParam: element,
                        ),
                      );
                    },
                  ),
                  flex: 1,
                ),
                FlexSizedBox(
                  width: 381,
                  height: 82,
                  child: NFlex(
                    direction: Axis.horizontal,
                    spacing: 10,
                    children: [
                      FlexSizedBox(
                        width: null,
                        height: 60,
                        child: GestureDetector(
                          child: const Icon(
                            IconData(61532, fontFamily: 'MaterialIcons'),
                            color: Color(4278190080),
                            size: 40,
                          ),
                          onTap: () {},
                          trackpadScrollToScaleFactor: const Offset(0, 0),
                        ),
                      ),
                      FlexSizedBox(
                        height: 60,
                        child: TextFormField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(4)),
                            filled: true,
                            hintText: 'write something...',
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide:
                                    const BorderSide(color: Color(4294967295))),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(0),
                                borderSide:
                                    const BorderSide(color: Color(4287236332))),
                          ),
                          controller: textcontroller,
                          maxLines: 10,
                          showCursor: true,
                        ),
                        flex: 1,
                      ),
                      FlexSizedBox(
                        height: 60,
                        child: CustomButton(
                          onPressed: () {
                            isLoading = true;
                            messageList?.insert(
                                0,
                                ChatMessageObject(
                                    message: textcontroller.text));
                            OpenAI()
                                .SendMessage(message: textcontroller.text)
                                .then((value) {
                              messageList?.insert(
                                  0,
                                  ChatMessageObject(
                                      message:
                                          value.choices![0]?.message?.content,
                                      isUserSender: false));
                              isLoading = false;
                              setState(() {});
                            }, onError: (error) {
                              print('error: ${error}');
                            });
                            textcontroller.clear();
                            setState(() {});
                          },
                          child: Text(
                            createText(),
                            style: const TextStyle(color: Color(4294967295)),
                          ),
                          color: const Color(4287236332),
                        ),
                      )
                    ],
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                  ),
                )
              ],
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
            ),
          ),
        ),
      ),
      appBar: AppBar(
        title: Text(
          'Market Buddy',
          style: const TextStyle(),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
      ),
    );
  }

  String createText() {
    if (isLoading!) {
      return '...';
    } else {
      return 'Send';
    }
  }
}
