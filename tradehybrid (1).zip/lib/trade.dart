import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:flutter_html/flutter_html.dart';

@NowaGenerated({'auto-width': 390, 'auto-height': 844})
class trade extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const trade({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          alignment: const Alignment(0, 0),
          children: [
            Positioned(
              width: 390,
              height: 844,
              child: Html(
                data:
                    '<!-- TradingView Widget BEGIN -->\n<div class="tradingview-widget-container" style="height:100%;width:100%">\n  <div class="tradingview-widget-container__widget" style="height:calc(100% - 32px);width:100%"></div>\n  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/" rel="noopener nofollow" target="_blank"><span class="blue-text">Track all markets on TradingView</span></a></div>\n  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js" async>\n  {\n  "autosize": true,\n  "symbol": "CME_MINI:NQ1!",\n  "interval": "D",\n  "timezone": "Etc/UTC",\n  "theme": "dark",\n  "style": "1",\n  "locale": "en",\n  "backgroundColor": "rgba(0, 0, 0, 1)",\n  "withdateranges": true,\n  "hide_side_toolbar": false,\n  "allow_symbol_change": true,\n  "details": true,\n  "hotlist": true,\n  "calendar": false,\n  "support_host": "https://www.tradingview.com"\n}\n  </script>\n</div>\n<!-- TradingView Widget END -->',
                shrinkWrap: false,
              ),
              top: 0,
              left: 0,
            )
          ],
        ),
      ),
    );
  }
}
