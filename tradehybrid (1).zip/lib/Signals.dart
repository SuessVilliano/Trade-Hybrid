import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:tradehybrid/integrations/firestore_service.dart';

@NowaGenerated({'auto-width': 390, 'auto-height': 844})
class Signals extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const Signals({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          alignment: const Alignment(0, 0),
          children: [
            Positioned(
              top: 593,
              left: 148.5,
              height: 40,
              child: CustomButton(
                onPressed: () {
                  FirestoreService.addProduct().then((value) {
                    FirestoreService.addProduct().then((value) {},
                        onError: (error) {
                      print('error: ${error}');
                    });
                  }, onError: (error) {
                    print('error: ${error}');
                  });
                },
                child: const Text(
                  'Add Product',
                  style: TextStyle(color: Color(4294967295)),
                ),
                color: const Color(4278190080),
              ),
            )
          ],
        ),
      ),
    );
  }
}
