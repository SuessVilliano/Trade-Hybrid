import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:tradehybrid/integrations/firebase.dart';
import 'package:tradehybrid/Welcome.dart';
import 'package:tradehybrid/signup.dart';

@NowaGenerated({'auto-width': 390, 'auto-height': 844})
class LoginScreen extends StatefulWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() {
    return _LoginScreenState();
  }
}

@NowaGenerated()
class _LoginScreenState extends State<LoginScreen> {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  TextEditingController password = TextEditingController();

  TextEditingController email = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          alignment: const Alignment(0, 0),
          children: [
            Positioned(
              top: 163.00000000000003,
              left: 35,
              width: 293,
              child: Form(
                key: formKey,
              ),
            ),
            Positioned(
              top: 75,
              left: 77,
              width: 233,
              height: 74,
              child: Text(
                'Login',
                style:
                    const TextStyle(fontSize: 44, fontFamily: 'Alfa Slab One'),
                textAlign: TextAlign.center,
              ),
            ),
            Positioned(
              top: 171,
              left: 64,
              width: 262,
              height: 216,
              child: Stack(
                fit: StackFit.expand,
                alignment: const Alignment(0, 0),
                children: [
                  Positioned(
                    top: 166.99999999999997,
                    left: 84,
                    height: 40,
                    child: CustomButton(
                      onPressed: () {
                        formKey.currentState?.validate();
                        if (true) {
                          FirebaseService()
                              .signInWithEmailAndPassword(
                                  email.text, password.text)
                              .then((value) {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => const Welcome()));
                          }, onError: (error) {
                            print('error: ${error}');
                          });
                        }
                        FirebaseService()
                            .signInWithEmailAndPassword(
                                email.text, password.text)
                            .then((value) {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => const Welcome()));
                        }, onError: (error) {
                          print('error: ${error}');
                        });
                      },
                      child: const Text(
                        'Sign in',
                        style: TextStyle(
                            color: Color(4294967295),
                            backgroundColor: Color(16777215)),
                      ),
                      color: const Color(4278190080),
                    ),
                  ),
                  Positioned(
                    top: 80,
                    left: 0,
                    width: 258,
                    height: 48,
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: 'enter password...',
                        filled: true,
                        labelStyle: const TextStyle(),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4)),
                        prefixIcon: const Icon(
                          IconData(62634, fontFamily: 'MaterialIcons'),
                          color: Color(4278190080),
                        ),
                      ),
                      obscureText: true,
                      validator: (value) {
                        if (value == null || value!.isEmpty) {
                          return 'Field is required';
                        }
                        if (value!.length < 6) {
                          return 'Too small';
                        }
                        return null;
                      },
                      controller: password,
                    ),
                  ),
                  Positioned(
                    top: 0,
                    left: 0,
                    width: 258,
                    height: 48,
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: 'enter email...',
                        filled: true,
                        labelStyle: const TextStyle(),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(4)),
                        prefixIcon: const Icon(
                          IconData(57473, fontFamily: 'MaterialIcons'),
                          color: Color(4278190080),
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value!.isEmpty) {
                          return 'Field is required';
                        }
                        if (!RegExp(kEmailValidationRegex).hasMatch(value!)) {
                          return 'Invalid email';
                        }
                        return null;
                      },
                      controller: email,
                    ),
                  )
                ],
              ),
            ),
            Positioned(
              top: 447,
              left: 106.5,
              width: 173.5,
              height: 42,
              child: GestureDetector(
                child: Text(
                  'Need an account?\nSign up here',
                  style: TextStyle(decoration: TextDecoration.underline),
                  textAlign: TextAlign.center,
                ),
                onTap: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => const signup()));
                },
                trackpadScrollToScaleFactor: const Offset(0, 0),
                onDoubleTapCancel: () {},
              ),
            ),
            Positioned(
              top: 559,
              left: 108.5,
              height: 45,
              width: 170,
              child: CustomButton(
                onPressed: () {
                  FirebaseService().signInWithGoogle().then((value) {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => const Welcome()));
                  }, onError: (error) {
                    print('error: ${error}');
                  });
                },
                child: const Text(
                  'Login With Google',
                  style: TextStyle(color: Color(4278190080)),
                ),
                color: const Color(4291282887),
              ),
            )
          ],
        ),
      ),
    );
  }

  void InState() {
    if (email == TextEditingController()) {}
  }
}
